import{l as o,a as r}from"../chunks/BV31ZS5P.js";export{o as load_css,r as start};
